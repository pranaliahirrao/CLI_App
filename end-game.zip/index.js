var readlineSync = require("readline-sync") ;

var userNAme = readlineSync.question("What's your Name ?? ");

var score = 0 ;

console.log("Welcome " + userNAme + " to 'DO YOU KNOW' Pranali !") ;
console.log("----x-------x-------x-------x-------x-------x-----") ;

// function 

function play(question , answer) {
  var userAnswer = readlineSync.question(question) ;

  if(userAnswer == answer){
    console.log("Yes, RIGHT !!") ;
    score += 1 ;
  }else{
    console.log("Oopss , its Wrong :( ") ;
    score -= 1 ;
  }
  console.log("Your score is: "+ score) ;
  console.log("----------------------------") ;
}

// array of objects
var Questions = [
  {
    question : "Pranali's clg name? " , 
    answer: "Viit"
  },
  {
    question : "Her fav actor? " , 
    answer : "MaheshBabu"
  },
  {
    question : "Fav drink ?" ,
    answer : "Tea" 
  },
  {
    question : "Pranali's favorite Book ?",
    answer : "Her Last Wish" 
  },
  {
    question : "Which color pranali like the most ?" ,
    answer : "Purple" 
  }
] ;

// for loop to run FUNCTION 

for(var i=0 ; i<Questions.length ; i++ ){
  var currQuetion = Questions[i] ;
  play(currQuetion.question , currQuetion.answer) ;
}

// play("Pranali's clg name? " , "viit") ;
// play("Her fav actor? " , "MaheshBabu") ;